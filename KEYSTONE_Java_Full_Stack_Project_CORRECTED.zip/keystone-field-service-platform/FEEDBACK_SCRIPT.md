# Feedback Video — Reflection Script

## What I learned
I learned how a Java Spring Boot application is separated into controllers, services, repositories, DTOs and security components. I also learned how React communicates with REST APIs and how PostgreSQL data is managed through JPA and Flyway.

## Biggest challenge
The most challenging part was the work-order lifecycle because a status change is not just a UI action. The server must check the current status, the user's role, the assignment and the allowed next state before writing the change and its audit history.

## Security learning
I learned that hiding a button in React is not security. The API must verify the JWT and role on every protected operation. Customer data also needs organisation-level scoping.

## Database learning
I learned how related entities such as customers, sites, work orders, status history, parts and time logs are represented with relational tables and JPA relationships.

## Key takeaway
My main takeaway is that a professional application is more than CRUD screens. Validation, authorization, transactions, audit history, deployment and documentation are all part of a complete product.
