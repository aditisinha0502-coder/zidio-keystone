# 3–5 Minute Demo Script

## 0:00–0:30 — Introduction
Show the landing/login page.

Say:
“KEYSTONE is a Java full-stack field-service management platform. It connects customers, dispatchers, technicians and managers around one governed work-order lifecycle.”

## 0:30–1:10 — Customer
Log in as customer.

1. Open the customer portal.
2. Show existing work orders.
3. Create a request for a site.
4. Open the request and show its status/history.

Say:
“The customer can create requests and only see work belonging to their organisation.”

## 1:10–1:50 — Dispatcher
Log in as dispatcher.

1. Open Work Orders.
2. Show search/filtering.
3. Create or open a work order.
4. Assign it to the technician.
5. Show that the status becomes ASSIGNED.

Say:
“Assignment is protected on the server, not only by hiding UI buttons.”

## 1:50–2:50 — Technician
Log in as technician.

1. Open assigned work.
2. Start the job.
3. Put it on hold and resume it.
4. Add a part.
5. Add time.
6. Complete the job.

Say:
“The lifecycle is enforced by the backend service. Invalid state jumps are rejected.”

## 2:50–3:35 — Manager
Log in as manager.

1. Open dashboard.
2. Show status counts.
3. Show overdue/SLA information.
4. Show customer/site or work-order administration.
5. Explain that manager can close completed work.

## 3:35–4:00 — API
Open Swagger UI.

Show:
- login
- work orders
- status transition
- parts
- time
- reports

Close with:
“The project uses Spring Boot, Spring Security JWT, JPA, PostgreSQL, Flyway and React TypeScript, with a layered architecture and server-side authorization.”
