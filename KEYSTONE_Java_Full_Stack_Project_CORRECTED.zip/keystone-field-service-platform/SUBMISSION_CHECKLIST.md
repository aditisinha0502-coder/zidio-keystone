# Submission Checklist

## Step 1 — Source Code / Figma — 5 marks
- [ ] Push this repository to GitHub/GitLab.
- [ ] Confirm the repository is public or mentor-accessible.
- [ ] Submit repository URL.

## Step 2 — Live Deployment — 5 marks
- [ ] Deploy PostgreSQL.
- [ ] Deploy Spring Boot backend.
- [ ] Deploy React frontend.
- [ ] Verify Swagger.
- [ ] Submit frontend URL.
- [ ] Submit backend URL.
- [ ] Submit Swagger URL.

## Step 3 — Demo Video — 4 marks
- [ ] Record 3–5 minutes.
- [ ] Show customer.
- [ ] Show dispatcher.
- [ ] Show technician.
- [ ] Show manager.
- [ ] Show lifecycle.
- [ ] Show Swagger.
- [ ] Upload as unlisted YouTube or Drive.
- [ ] Submit link.

## Step 4 — Feedback Video — 4 marks
- [ ] Explain what you learned.
- [ ] Explain challenges.
- [ ] Explain key takeaways.
- [ ] Upload video.
- [ ] Submit link.

## Step 5 — Project Report — 2 marks
- [ ] Export PROJECT_REPORT.md to PDF/Doc.
- [ ] Add architecture screenshots.
- [ ] Add application screenshots.
- [ ] Add live URLs.
- [ ] Submit report.

Do not invent URLs. Use the actual links created after deployment.
