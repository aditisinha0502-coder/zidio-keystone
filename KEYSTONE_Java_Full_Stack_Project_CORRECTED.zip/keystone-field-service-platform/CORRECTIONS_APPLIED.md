# Corrections Applied

This version applies the security/authorization fixes identified during project review.

## Backend fixes
1. `WorkOrderService.create(...)`
   - Now receives the authenticated user.
   - A CUSTOMER can only create a work order for their own customer account.
2. `WorkOrderController.status(...)`
   - Restricted to MANAGER, DISPATCHER, and TECHNICIAN.
3. `WorkOrderService.status(...)`
   - Defense-in-depth check rejects CUSTOMER status changes even if controller rules are changed later.
4. `CustomerController.sites(...)`
   - Restricted to MANAGER and DISPATCHER so a customer cannot request another customer's sites by ID.

## Notes
- No production secrets or demo credentials were changed.
- Run backend tests with `mvn test`.
- Run frontend with `npm install` followed by `npm run build`.
